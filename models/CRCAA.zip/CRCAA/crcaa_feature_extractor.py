import torch.nn as nn
import torch.nn.functional as F

import torchvision.models as models
class Feature_extractor(nn.Module):
    def __init__(self):
        super(Feature_extractor, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=32, kernel_size=15, stride=4,padding=0)
        self.pool1 = nn.MaxPool1d(kernel_size=3, stride=2,padding=1)
        self.conv2 = nn.Conv1d(in_channels=32, out_channels=64, kernel_size=5, stride=2)
        self.pool2 = nn.MaxPool1d(kernel_size=3, stride=2,padding=1)
        self.conv3 = nn.Conv1d(in_channels=64, out_channels=96, kernel_size=5, stride=1,padding=2)
        self.pool3 = nn.MaxPool1d(kernel_size=3, stride=1)
        self.conv4 = nn.Conv1d(in_channels=96, out_channels=64, kernel_size=5, stride=1)
        self.conv5 = nn.Conv1d(in_channels=64, out_channels=32, kernel_size=5, stride=1)
        self.conv6 = nn.Conv1d(in_channels=32, out_channels=16, kernel_size=5, stride=2)
        self.pool4 = nn.MaxPool1d(kernel_size=3, stride=2)

        self.flatten = nn.Flatten()
        


    def forward(self, x):
        x = self.pool1(F.relu(self.conv1(x)))
        
        x = self.pool2(F.relu(self.conv2(x)))
        
        x = self.pool3(F.relu(self.conv3(x)))
        
        x = self.conv4(F.relu(x))
        
        x = self.conv5(F.relu(x))
        
        x = self.conv6(F.relu(x))
        
        x = self.pool4(F.relu(x))
        

        # Flatten
        feature = self.flatten(x)
        
        
        return feature